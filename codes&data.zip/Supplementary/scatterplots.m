clc
clear all
close all
f1 = xlsread('Ecoli_data.xlsx');
 
subplot(2,2,1)
scatter(f1(:,1),f1(:,3),10,'+')
hold on
for i=1:length(f1)
    if f1(i,3)>70
        f1(i,3)=70;
    end
end     
scatter(f1(:,1),f1(:,3),30)
xlabel({'Pass number';'a)'},'FontSize',14,'Fontname','Times new roman')
ylabel('Phred quality score','FontSize',14,'Fontname','Times new roman')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

f2 = xlsread('lambdadata.xlsx');

subplot(2,2,2)
scatter(f2(:,1),f2(:,3),10,'+')
hold on
for i=1:length(f2)
    if f2(i,3)>70
        f2(i,3)=70;
    end
end     
scatter(f2(:,1),f2(:,3),30)
xlabel({'Pass number';'b)'},'FontSize',14,'Fontname','Times new roman')
ylabel('Phred quality score','FontSize',14,'Fontname','Times new roman')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

f3 = xlsread('AD_skeletal.xlsx');

%subplot(3,1,3)
subplot('Position',[0.35 0.1 0.3 0.3])
scatter(f3(:,1),f3(:,3),10,'+')
hold on
for i=1:length(f3)
    if f3(i,3)>70
        f3(i,3)=70;
    end
end     
scatter(f3(:,1),f3(:,3),30)
xlabel({'Pass number';'c)'},'FontSize',14,'Fontname','Times new roman')
ylabel('Phred quality score','FontSize',14,'Fontname','Times new roman')