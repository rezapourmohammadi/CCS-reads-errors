function [ x ] = randoms( m,n,mu,sigma )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
i=1;
y=[];
while (i<=m*n)
    y = randn*sigma+mu;
    if (y>=3 && y<=14)
        x(i) = (y);
        i=i+1;
    end
end
x = reshape(x,n,m)';
end

