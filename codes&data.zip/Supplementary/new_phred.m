% EQSC Model's Phred quality score
% for Lambda and E.coli datasets
clc
clear all
close all
% FOR E. Coli Dataset
% find Log-normal parameters for the CCS read's length
f1 = xlsread('Ecoli_data.xlsx');
x1=min(f1(:,2)):max(f1(:,2));
E1=sum(f1(:,2))/length(f1);
var1=var(f1(:,2));
sigma21=log(var1/E1^2+1);
mu1=log(E1)-sigma21/2;

n1txt = fopen('ecoli.txt','w+');
N_try = 40;
pass_number = 3:20;
ptot = [];
for m = pass_number
    for tt = 1:N_try
    L_ccs = round(lognrnd(mu1,sigma21));% 7.9254,0.2946 %6.7935,0.2260
    ptot = zeros(1,L_ccs);
    parfor h = 1:L_ccs
        p6 = 1-10.^(-(randoms(1,1,9.12,2))/10);%rand*1.76+8.24
        p1 = 6/15*(1-p6);
        p2 = 3/15*(1-p6);
        p3 = 2/15*(1-p6);
        p4 = 2/15*(1-p6);
        p5 = 2/15*(1-p6);

    for i1=0:m/2
        i2m = max(m-i1,m/2);
        for i2=0:i2m
            i3m = max(m-i1-i2,m/2);
            for i3=0:i3m
                i4m = max(m-i1-i2-i3,m/2);
                for i4=0:i4m
                    i5m = max(m-i1-i2-i3-i4,m/2);
                    for i5=0:i5m
                        i6 = m-i1-i2-i3-i4-i5;
                        [n,index] = max([i1,i2,i3,i4,i5,i6]);
                        if(i6==n)%(index==6)
p = factorial(m)/factorial(i1)/factorial(i2)/factorial(i3)...
    /factorial(i4)/factorial(i5)/factorial(i6);
ptot(h) = ptot(h)+p*p1^i1*p2^i2*p3^i3*p4^i4*p5^i5*p6^i6;
                        end
                    end
                end
            end
        end
    end
    end
    ptot_avg(m-2,tt) = mean(ptot);
    fprintf(n1txt,'%d, %d, %f \n',m,tt,-10*log10(1-ptot_avg(m-2,tt)));

    end
end
fclose(n1txt);
phred = -10*log10(1-ptot_avg);
% plot(pass_number,phred)
% boxplot(phred',pass_number)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FOR LAMBDA Dataset
clear all
% find Log-normal parameters for the CCS read's length
f2 = xlsread('lambdadata.xlsx');
x2=min(f2(:,2)):max(f2(:,2));
E2=sum(f2(:,2))/length(f2);
var2=var(f2(:,2));
sigma22=log(var2/E2^2+1);
mu2=log(E2)-sigma22/2;

n1txt = fopen('Lambda.txt','w+');
N_try = 40;
pass_number = 3:20;
ptot = [];
for m = pass_number
    for tt = 1:N_try
    L_ccs = round(lognrnd(mu2,sigma22));% 7.9254,0.2946 %6.7935,0.2260
    ptot = zeros(1,L_ccs);
    parfor h = 1:L_ccs
        p6 = 1-10.^(-(randoms(1,1,9.12,2))/10);%rand*1.76+8.24
        p1 = 6/15*(1-p6);
        p2 = 3/15*(1-p6);
        p3 = 2/15*(1-p6);
        p4 = 2/15*(1-p6);
        p5 = 2/15*(1-p6);

    for i1=0:m/2
        i2m = max(m-i1,m/2);
        for i2=0:i2m
            i3m = max(m-i1-i2,m/2);
            for i3=0:i3m
                i4m = max(m-i1-i2-i3,m/2);
                for i4=0:i4m
                    i5m = max(m-i1-i2-i3-i4,m/2);
                    for i5=0:i5m
                        i6 = m-i1-i2-i3-i4-i5;
                        [n,index] = max([i1,i2,i3,i4,i5,i6]);
                        if(i6==n)%(index==6)
p = factorial(m)/factorial(i1)/factorial(i2)/factorial(i3)...
    /factorial(i4)/factorial(i5)/factorial(i6);
ptot(h) = ptot(h)+p*p1^i1*p2^i2*p3^i3*p4^i4*p5^i5*p6^i6;
                        end
                    end
                end
            end
        end
    end
    end
    ptot_avg(m-2,tt) = mean(ptot);
    fprintf(n1txt,'%d, %d, %f \n',m,tt,-10*log10(1-ptot_avg(m-2,tt)));

    end
end
fclose(n1txt);
phred = -10*log10(1-ptot_avg);
% plot(pass_number,phred)
% boxplot(phred',pass_number)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FOR AD skeletal Dataset
clear all
% find Log-normal parameters for the CCS read's length
f2 = xlsread('AD_skeletal.xlsx');
x2=min(f2(:,2)):max(f2(:,2));
E2=sum(f2(:,2))/length(f2);
var2=var(f2(:,2));
sigma22=log(var2/E2^2+1);
mu2=log(E2)-sigma22/2;

n1txt = fopen('AD_skeletal.txt','w+');
N_try = 40;
pass_number = 3:20;
ptot = [];
for m = pass_number
    for tt = 1:N_try
    L_ccs = round(lognrnd(mu2,sigma22));% 7.9254,0.2946 %6.7935,0.2260
    ptot = zeros(1,L_ccs);
    parfor h = 1:L_ccs
        p6 = 1-10.^(-(randoms(1,1,9.12,2))/10);%rand*1.76+8.24
        p1 = 6/15*(1-p6);
        p2 = 3/15*(1-p6);
        p3 = 2/15*(1-p6);
        p4 = 2/15*(1-p6);
        p5 = 2/15*(1-p6);

    for i1=0:m/2
        i2m = max(m-i1,m/2);
        for i2=0:i2m
            i3m = max(m-i1-i2,m/2);
            for i3=0:i3m
                i4m = max(m-i1-i2-i3,m/2);
                for i4=0:i4m
                    i5m = max(m-i1-i2-i3-i4,m/2);
                    for i5=0:i5m
                        i6 = m-i1-i2-i3-i4-i5;
                        [n,index] = max([i1,i2,i3,i4,i5,i6]);
                        if(i6==n)%(index==6)
p = factorial(m)/factorial(i1)/factorial(i2)/factorial(i3)...
    /factorial(i4)/factorial(i5)/factorial(i6);
ptot(h) = ptot(h)+p*p1^i1*p2^i2*p3^i3*p4^i4*p5^i5*p6^i6;
                        end
                    end
                end
            end
        end
    end
    end
    ptot_avg(m-2,tt) = mean(ptot);
    fprintf(n1txt,'%d, %d, %f \n',m,tt,-10*log10(1-ptot_avg(m-2,tt)));

    end
end
fclose(n1txt);
phred = -10*log10(1-ptot_avg);
% plot(pass_number,phred)
% boxplot(phred',pass_number)