import math

g = open("ccs.fastq","r")
fastqline = g.readlines()
phredvec = []
idvec = []
for i in range(len(fastqline)/4):
    x = []
    length = len(fastqline[4*i+3]) # CCS length
    accuracy = 0
    for j in range(length-1): #omit '\n' at the end of each line
        phred = ord(fastqline[4*i+3][j])-33 # each base quality
        x = x+[phred]
        accuracy = accuracy+(1-10**(-phred/10.0))
        
    accuracymean = float(accuracy)/(length-1)   
    phredvec = phredvec+[-10*math.log(1-accuracymean)/math.log(10)]
    fastq_id = fastqline[4*i].split('/')[1]
    idvec = idvec+[fastq_id]

h = open ("data.csv", "w")
h.write("qname;npass;qlen;phred quality\n")
f = open("ccs_statistics.csv","r")
csvline = f.readlines()

for i in range(len(csvline)-1):
    x = csvline[i+1].split(';')
    csv_id = x[0].split('/')[1]
    id_index = idvec.index(csv_id)
    x[3] = phredvec[id_index]
    x2 = ""
    for j in range(len(x)-1):
        x2 = x2+str(x[j])+";"
    x2 = x2+str(x[len(x)-1])
    h.write(x2)
    h.write('\n')

##h = open ("data.csv", "w")
h.close()
f.close()
g.close()
