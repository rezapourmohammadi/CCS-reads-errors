% fixed length of raw reads
clc
clear all
close all
try_number = 1000; % number of trial
% sumlenz = 0; % Sum of the number of errors in CCS reads
epsilon_1 = 0.06; % error rate for insertion
epsilon_2 = 0.09; % error rate for deletion
epsilon_3 = 0.11; % error rate for subs1
epsilon_4 = 0.13; % error rate for subs2
epsilon_5 = 0.15; % error rate for subs3


L = 150e3; % Length of raw read
% ccs_L = 2000;
passnumber=[3,7];
textbox=[{'a)'},{'b)'}];

for m=passnumber
    sumlenz=0;
    ccs_L = floor(L/m); % lenght of CCS read
    for h = 1:try_number
        z = []; % vector of
        y = zeros(6,ccs_L); % vector of the numbers of error happened for each nucleotide of ccs read
        for i = 1:m
            position =[];
            x = rand(1,ccs_L);
            position = find(x <= epsilon_1); % position of errors
            for j = 1:length(position)
                y(1,position(j)) = y(1,position(j))+1;
            end
            position =[];
            position = find((x> epsilon_1) & (x <= epsilon_2)); % position of errors
            for j = 1:length(position)
                y(2,position(j)) = y(2,position(j))+1;
            end
            position =[];
            position = find((x> epsilon_2) & (x <= epsilon_3)); % position of errors
            for j = 1:length(position)
                y(3,position(j)) = y(3,position(j))+1;
            end
            position =[];
            position = find((x> epsilon_3) & (x <= epsilon_4)); % position of errors
            for j = 1:length(position)
                y(4,position(j)) = y(4,position(j))+1;
            end
            position =[];
            position = find((x> epsilon_4) & (x <= epsilon_5)); % position of errors
            for j = 1:length(position)
                y(5,position(j)) = y(5,position(j))+1;
            end
            position =[];
            position = find(x> epsilon_5);
            for j = 1:length(position)
                y(6,position(j)) = y(6,position(j))+1;
            end
        end
        [d,indexes] = max(y);
        correctnuc = length(find(indexes==6));
        %z = find(y>=m/2); % error happened when in more than half of pass number we have error 
        lenz(h) = ccs_L- correctnuc; % the number of errors in ccs read in each trial
        err_rate(h) = lenz(h)/ccs_L;
        phredlike(h) = 10*(-log10(lenz(h)/ccs_L));
        sumlenz = sumlenz+lenz(h);
    end
    sumlenz/try_number % average number of error in ccs read
    index = find(passnumber==m);
    subplot(1,2,index)
    hist(lenz/ccs_L,length(lenz)) % histogram of number of errors in ccs reads
    hold on
    epsilon2 = sumlenz/try_number/ccs_L;
    ss=normpdf(min(lenz):max(lenz),epsilon2*ccs_L,sqrt(epsilon2*(1-epsilon2)*ccs_L));
    plot((min(lenz):max(lenz))/ccs_L,try_number*ss,'r--','Linewidth',3)
    xlabel({'Error rate',[cell2mat(textbox(index)),' pass number m = ',num2str(m)]},'FontSize',16,'Fontname','Times new roman')
    ylabel(['Number of erroneous reads among ',num2str(try_number),' reads'],'FontSize',16,'Fontname','Times new roman')
    h = legend('Resulted dist.','Estimated normal dist.');
    set(h,'interpreter','latex','FontSize',14,'FontWeight','bold','Fontname','Times new roman')
end

