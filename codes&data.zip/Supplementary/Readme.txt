To get the output files of the CCS analysis with SMRTLink software 
on the raw PacBio datasets, especially "CCS.fastq", use the following links:

1-Lambda and E. coli datasets:
https://drive.google.com/file/d/1L9ITRRz9h0hklD4JXEqWz3qUcfwEjXp2/view?usp=sharing

2-Alzheimer disease skeletal dataset:
https://drive.google.com/file/d/1xiXAmYbN1r4ULAEzoyBn-Zxh_7ontjrm/view?usp=sharing