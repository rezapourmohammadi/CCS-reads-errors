clc
clear all
close all
try_number = 1000; % number of trial
epsilon = 0.15; % error rate for raw reads
L = 150e3; % Length of raw read
passnumber = [3,7]; % pass number
textbox=[{'a)'},{'b)'}];
for m=passnumber
    sumlenz = 0; % Sum of the number of errors in CCS reads
    ccs_L = floor(L/m); % lenght of CCS read
    for h = 1:try_number
        z = []; % vector of
        y = zeros(1,ccs_L); % vector of the numbers of error happened for each nucleotide of ccs read
        for i = 1:m
            position = [];
            x = rand(1,ccs_L);
            position = find(x <= epsilon); % position of errors
            for j = 1:length(position)
                y(position(j)) = y(position(j))+1;
            end
        end
        z = find(y>=m/2); % error happened when in more than half of pass number we have error 
        lenz(h) = length(z); % the number of errors in ccs read in each trial
        sumlenz = sumlenz+length(z);
    end
    index = find(passnumber==m);
    sumlenz/try_number % average number of error in ccs read
    subplot(1,2,index)
    hist(lenz/ccs_L,length(lenz)) % histogram of number of errors in ccs reads
    hold on
    epsilon2 = sumlenz/try_number/ccs_L;
    ss=normpdf(min(lenz):max(lenz),epsilon2*ccs_L,sqrt(epsilon2*(1-epsilon2)*ccs_L));
    plot([min(lenz):max(lenz)]/ccs_L,try_number*ss,'r--','Linewidth',3)
    xlabel({'Error rate',[cell2mat(textbox(index)),' pass number m = ',num2str(m)]},'FontSize',16,'Fontname','Times new roman')
    ylabel(['Number of erroneous reads among ',num2str(try_number),' reads'],'FontSize',16,'Fontname','Times new roman')
    h = legend('Resulted dist.','Estimated normal dist.');
    set(h,'interpreter','latex','FontSize',14,'FontWeight','bold','Fontname','Times new roman')
end