clc
clear all
close all
format long
n_try = 40;
pass_number = 3:20;
sum2 = zeros(1,length(pass_number)); %for EQSC
avg1 = zeros(1,length(pass_number)); %for E. coli data
avg2 = zeros(1,length(pass_number)); %for lambda data
f1=xlsread('Ecoli_data.xlsx');
for m=pass_number
    sum1 = 0;
    N = 0;
    for i=1:length(f1)
        if f1(i,1)==m
            sum1=sum1+10^(-f1(i,3)/10.0);
            N=N+1;
        end
    end
    avg1(m-2)= sum1/N;
end
phred1 = -10*log10(avg1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
f2=xlsread('lambdadata.xlsx');
for m=pass_number
    sum1 = 0;
    N = 0;
    for i=1:length(f2)
        if f2(i,1)==m
            sum1=sum1+10^(-f2(i,3)/10.0);
            N=N+1;
        end
    end
    avg2(m-2)= sum1/N;
end
phred2 = -10*log10(avg2);
% hold on
% plot(pass_number, phred2,'r')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
f3=xlsread('AD_skeletal.xlsx');
for m=pass_number
    sum1 = 0;
    N = 0;
    for i=1:length(f3)
        if f3(i,1)==m
            sum1=sum1+10^(-f3(i,3)/10.0);
            N=N+1;
        end
    end
    avg3(m-2)= sum1/N;
end
phred3 = -10*log10(avg3);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fid = fopen('ecoli.txt','r');
a = fscanf(fid,'%d , %d , %f \n');

for i=1:length(a)/3
    b(i)=a(3*i-2);% pass number
    c(i)=a(3*i);%quality
end

for j=1:length(c)/n_try
    phred4(j)=-10*log10(mean(10.^(-c((j-1)*n_try+1:j*n_try)/10)));
end
%  phred4=phred4(pass_number-2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fid = fopen('lambda.txt','r');
a = fscanf(fid,'%d , %d , %f \n');

for i=1:length(a)/3
    b(i)=a(3*i-2);% pass number
    c(i)=a(3*i);%quality
end

for j=1:length(c)/n_try
    phred5(j)=-10*log10(mean(10.^(-c((j-1)*n_try+1:j*n_try)/10)));
end
%  phred5=phred5(pass_number-2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fid = fopen('AD_skeletal.txt','r');
a = fscanf(fid,'%d , %d , %f \n');

for i=1:length(a)/3
    b(i)=a(3*i-2);% pass number
    c(i)=a(3*i);%quality
end

for j=1:length(c)/n_try
    phred6(j)=-10*log10(mean(10.^(-c((j-1)*n_try+1:j*n_try)/10)));
end
%  phred6=phred6(pass_number-2);

figure
bar(pass_number,[phred2;phred5;phred1;phred4;phred3;phred6]','hist')
xlabel('Pass number','FontName','Times New Roman','FontSize',16)
ylabel('Phred quality score of the reads','FontName','Times New Roman','FontSize',16)
h = legend('Lambda dataset','Lambda EQSC model','E. coli dataset','E. coli EQSC model','AD dataset','AD EQSC model');
set(h,'interpreter','latex','FontName','Times New Roman','FontSize',16,'FontWeight','bold')

c1=corrcoef(phred1,phred4) % E. coli & it's EQSC
c2=corrcoef(phred2,phred5) % Lambda & it's EQSC
c3=corrcoef(phred3,phred6) % AD skeletal & it's EQSC
c4=corrcoef(phred1,phred2) % E. coli & Lambda
c5=corrcoef(phred1,phred3) % E. coli & AD skeletal
c6=corrcoef(phred2,phred3) % AD skeletal & Lambda
c7=corrcoef(phred4,phred5) % E. coli & Lambda EQSCs
c8=corrcoef(phred4,phred6) % E. coli & AD skeletal EQSCs
c9=corrcoef(phred5,phred6) % AD skeletal & Lambda EQSCs

% sigma1=sum((phred1-phred2).^2)/length(phred1)
% sigma2=sum((phred1-phred3).^2)/length(phred1)
% sigma3=sum((phred2-phred4).^2)/length(phred2)
% %%%% bar chart
% figure
% bar(pass_number,[-10*log10(1-sum2)]','hist')
% % hold on
% % stairs(pass_number,-10*log10(1-sum2),'r','LineWidth',1.8)
% xlabel('Pass number','FontName','Times New Roman','FontSize',18)
% ylabel('Phred quality score of the reads','FontName','Times New Roman','FontSize',18)
% h = legend('QSC model','EQSC model');
% set(h,'interpreter','latex','FontSize',18,'FontWeight','bold')