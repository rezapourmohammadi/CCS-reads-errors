% Plot EQSC model Phred quality score Vs pass number
% for both Lambda and E. coli datasets 
clc
clear all
close all
fid = fopen('lambda.txt','r'); 
a = fscanf(fid,'%d , %d , %f \n');

for i=1:length(a)/3
    b(i)=a(3*i-2);% pass number
    c(i)=a(3*i);%quality
end
subplot(2,2,1)
boxplot(c,b)
xlabel({'Pass number';'a)'},'FontSize',14,'Fontname','Times new roman')
ylabel('Phred quality score','FontSize',14,'Fontname','Times new roman')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fid = fopen('ecoli.txt','r'); 
a = fscanf(fid,'%d , %d , %f \n');

for i=1:length(a)/3
    b(i)=a(3*i-2);% pass number
    c(i)=a(3*i);%quality
end
subplot(2,2,2)
boxplot(c,b)
xlabel({'Pass number';'b)'},'FontSize',14,'Fontname','Times new roman')
ylabel('Phred quality score','FontSize',14,'Fontname','Times new roman')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fid = fopen('AD_skeletal.txt','r'); 
a = fscanf(fid,'%d , %d , %f \n');

for i=1:length(a)/3
    b(i)=a(3*i-2);% pass number
    c(i)=a(3*i);%quality
end
%subplot(3,1,3)
subplot('Position',[0.35 0.1 0.3 0.3])
boxplot(c,b)
xlabel({'Pass number';'c)'},'FontSize',14,'Fontname','Times new roman')
ylabel('Phred quality score','FontSize',14,'Fontname','Times new roman')