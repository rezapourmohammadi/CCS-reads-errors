clc
clear all
close all
epsilon_1 = 0.06; % error rate for insertion
epsilon_2 = 0.03; % error rate for deletion
epsilon_3 = 0.02; % error rate for subs1
epsilon_4 = 0.02; % error rate for subs2
epsilon_5 = 0.02; % error rate for subs3
epsilon = epsilon_1+epsilon_2+epsilon_3+epsilon_4+epsilon_5;

pass_number = 3:15;
sum1 = zeros(1,length(pass_number)); %for QSC
sum2 = zeros(1,length(pass_number)); %for EQSC
for m = pass_number
    for i=0:ceil(m/2)-1
        x = factorial(m)/factorial(m-i)/factorial(i)*(epsilon)^i*(1-epsilon)^(m-i);
        sum1(m-2) = sum1(m-2)+x;
    end
end


for m=pass_number
    for nd=0:ceil(m/2)-1
        for ni=0:ceil(m/2)-1
            for ns1=0:ceil(m/2)-1
                for ns2=0:ceil(m/2)-1
                    for ns3=0:ceil(m/2)-1
                        nc = m-nd-ni-ns1-ns2-ns3;
                        l=[nd,ni,ns1,ns2,ns3,nc];
                        [c,d]=max(l);
                        if(d==6)
                            x2 = factorial(m)/factorial(nd)/factorial(ni)/factorial(ns1)...
                                /factorial(ns2)/factorial(ns3)/factorial(nc);
                            x2 = x2*epsilon_1^ni*epsilon_2^nd*epsilon_3^ns1...
                                *epsilon_4^ns2*epsilon_5^ns3*(1-epsilon)^nc;
                            sum2(m-2) = sum2(m-2)+x2;
                        end
                    end
                end
            end
        end
    end
end

% stairs(pass_number,sum1)
% hold on
% stairs(pass_number,sum2,'r')
% xlabel('Pass number','FontName','Times New Roman','FontSize',18)
% ylabel('Accuracy of the reads','FontName','Times New Roman','FontSize',18)
% h = legend('QSC model','EQSC model');
% set(h,'interpreter','latex','FontSize',18,'FontWeight','bold')
figure
stairs(pass_number,-10*log10(1-sum1),'--b','LineWidth',1.8)
hold on
stairs(pass_number,-10*log10(1-sum2),'r','LineWidth',1.8)
xlabel('Pass number','FontName','Times New Roman','FontSize',18)
ylabel('Phred accuracy score of the reads','FontName','Times New Roman','FontSize',18)
h = legend('QSC model','EQSC model');
set(h,'interpreter','latex','FontSize',18,'FontWeight','bold')

%%%% bar chart
figure
bar(pass_number,[-10*log10(1-sum1);-10*log10(1-sum2)]','hist')
% hold on
% stairs(pass_number,-10*log10(1-sum2),'r','LineWidth',1.8)
xlabel('Pass number','FontName','Times New Roman','FontSize',18)
ylabel('Phred accuracy score of the reads','FontName','Times New Roman','FontSize',18)
h = legend('QSC model','EQSC model');
set(h,'interpreter','latex','FontSize',18,'FontWeight','bold')